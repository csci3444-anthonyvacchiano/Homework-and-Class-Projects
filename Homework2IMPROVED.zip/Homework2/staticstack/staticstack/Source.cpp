#include <iostream>
#include <string>
using namespace std;

class person {
public:
	int age;
	string name;
	string id;
	person() { age = 0; name = " "; id = " "; }
	person(int a, string n, int i) { age = a; name = n; id = i; }
	string getName()
	{
		return name;
	}
	int getAge()
	{
		return age;
	}
	string getId()
	{
		return id;
	}
};
class stack
{
private:
	int size = 4;
	int top = -1;
public:
	person p[4];
void stack::push(string n, int a, string i)
{

	if (top == size )
	{
		cout << "stack is full";
		return;
	}
	else
	{
		top = top + 1;
		p[top].age = a;
		p[top].name = n;
		p[top].id = i;
	}

}
void stack::pop()
{
	if (top == -1 )
		cout << "\n Stack is empty";
	else
	{
		cout << p[top].name << " is deleted " << endl;
		top--;
	}
}

void stack::display()
{
	for (int i = top; i >= 0; i--)
	{
		cout << p[i].name << " is " << p[i].age << " years old with id: " << p[i].id << endl;
	}
}

};

int main()
{
	stack dstack;

	dstack.push("John", 20, "abc");
	dstack.push("Mike", 25, "123");
	dstack.push("Bill", 15, "abc123");

	dstack.display();

	dstack.pop();

	dstack.display();

}