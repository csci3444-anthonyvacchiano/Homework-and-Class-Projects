#include <iostream>
#include <string>
using namespace std;

class person {
public:
	int age;
	string name;
	string id;
	person() { age = 0; name = " "; id = " "; }
	person(int a, string n,string i) { age = a; name = n; id = i; }
};

class node
{
public:
	person p;
	node *next;
};


class stack
{
	node *top;
public:
	stack(){top = nullptr;}
	void push(string n, int a, string id);
	void pop();
	void display();
	~stack();
};

void stack::push(string n, int a, string i)
{
	person p;
	p.age = a;
	p.name = n;
	p.id = i;
	
	node *temp = new node();
	temp->p = p;
	

	temp->next = top;
	top = temp;
}

void stack::pop()
{
	if (top != NULL)
	{
		node *temp = top;
		top = top->next;
		cout << "erased  " << temp->p.name << " \n";
		delete temp;
	}
	else
		cout << "Stack empty \n";
}

void stack::display()
{
	node *temp = top;
	while (temp != NULL)
	{
		cout << temp->p.name << " is " << temp->p.age << " years old with id: " << temp->p.id <<" \n";
		temp = temp->next;
	}
}

stack::~stack()
{
	while (top != NULL)
	{
		node *temp = top;
		top = top->next;
		delete temp;
	}
}
int main()
{
	stack dstack;
	
	dstack.push("John", 20, "MG3");
	dstack.push("Mike", 25, "DS3");
	dstack.push("Bill", 15, "K3D");

	dstack.display();

	dstack.pop();

	dstack.display();


}