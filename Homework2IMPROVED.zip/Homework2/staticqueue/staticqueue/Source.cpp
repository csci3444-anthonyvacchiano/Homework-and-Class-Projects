#include <iostream>
#include <string>
using namespace std;

class person {
public:
	int age;
	string name;
	string id;
	person() { age = 0; name = " "; id = " "; }
	person(int a, string n, int i) { age = a; name = n; id = i; }
	string getName()
	{
		return name;
	}
	int getAge()
	{
		return age;
	}
	string getId()
	{
		return id;
	}
};

class queue
{
private:
	int size = 4;
	int front = -1;
	int rear = -1;
public:
	person p[4];
	void queue::enqueue(string n, int a, string i)
	{
		if (front == -1 && rear == -1)
		{
			front = 0;
			rear = 0;
			p[rear].age = a;
			p[rear].name = n;
			p[rear].id = i;
		}
		else {
			if (rear == (front - 1) % size) {
				cout << "error, no space in queue  \n" << endl;
				return;
			}
			rear = (rear + 1) % size;
			p[rear].age = a;
			p[rear].name = n;
			p[rear].id = i;
		}
	}

	void queue::dequeue()
	{
		if (front == -1 && rear == -1)
		{
			cout << "\n Queue is empty \n"; return;
		}

		cout << p[front].name << " is deleted " << endl;
		p[front].age = p[front + 1].age;
		p[front].age = NULL;
		p[front].name = p[front + 1].name;
		p[front].name = "  ";
		p[front].id = p[front + 1].id;
		p[front].id = "  ";



		if (front == rear)
		{
			front = rear = -1;
		}
		else
		{
			front = (front + 1) % size;
		}
	}
	void queue::print()
	{
		if (front == -1 && rear == -1) {
			cout << "No Elements in the Queue" << endl;
			return;
		}
		int i = front;
		cout << p[front].name << " is " << p[front].age <<  " years old with id: " << p[front].id << " \n";
		while (i != rear) {
			i = (i + 1) % size;
			cout << p[i].name << " is " << p[i].age << " years old with id: " << p[i].id << " \n";
		}
		cout << endl;
	}
};




int main()
{
	queue squeue;

	squeue.enqueue("John", 20, "mgs3");
	squeue.enqueue("Bill", 24, "ae3");
	squeue.enqueue("Jack", 19, "atcq");
	squeue.enqueue("Lucine", 29, "mca");

	squeue.print();

	squeue.dequeue();

	squeue.print();
	
	squeue.dequeue();

	squeue.print();

	squeue.dequeue();

	squeue.print();


}