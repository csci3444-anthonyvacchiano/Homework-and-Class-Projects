#include <iostream>
using namespace std;

int pascal(int, int);

int main()
{
	int COLUMN;
	const int ROW = 15;

	cout << "please enter the column: " << endl;
	cin >> COLUMN;
	pascal(COLUMN, ROW); /// try making an array
	for (int i = COLUMN; i < ROW; i++)
	{
		int tri = 1;
		for (int j = 1; j < (ROW - i); j++)
		{
			cout << "     ";
		}
		for (int k = 0; k <= i; k++)
		{ 
			cout << "      " << tri;
			tri = tri * (i - k) / (k + 1);
		}
		cout << endl << endl;
	}
	cout << endl;
	return 0;
}

int pascal(int column, int row) /// NO LOOPS HERE!
{
	if (column = 0)
	{
		return row = 1;
	}
	else if (column = row)
	{
		return column = 1;
		return row = 1;
	}
	else
	{
		return pascal(column-1, row-1) + pascal(column, row-1);
	}

}