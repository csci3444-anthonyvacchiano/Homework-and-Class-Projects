#include "Grade.h"
void grades::setgrade(double g)
{
	if (g >= 0)
		grade = g;
	else if (g < 0)
		throw negativegrade(g);
	else if (g > 100)
		throw greatergrade(g);
}