#pragma once
#ifndef GRADE_H
#define GRADE_H

class grades
{
private:
	double grade;
public:
	class greatergrade
	{
	private:
		double value;
	public:
		greatergrade(double ggrade)
		{
			value = ggrade;
		}
		double getvalue() const
		{
			return value;
		}
	};
	class negativegrade
	{
	private:
		double value;
	public:
		negativegrade(double ngrade)
		{
			value = ngrade;
		}
		double getvalue() const
		{
			return value;
		}
	};
	grades()
	{
		grade = 0;
	}
	void setgrade(double);
	double getgrade() const
	{
		return grade;
	}

};
#endif
