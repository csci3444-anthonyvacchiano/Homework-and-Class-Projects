#include <iostream>
#include "Grade.h"
using namespace std;

int main()
{

	const int MAX = 10;
	double grade;
	double average = 0;

	grades mygrade;
	for (int i = 0; i < MAX; i++)
		{
		cout << "please enter a grade #" << (i+1) << "  ";
			cin >> grade;

			try
			{
				mygrade.setgrade(grade);
			}
			catch (grades::negativegrade e)
			{
				grade = 0;
				cout << " grade was replaced with 0 \n";
			}
			catch (grades::greatergrade e)
			{
				grade = 100;
				cout << " grade was replaced with 100 \n";
			}
			average += grade;
		}
	cout << " the average is " << (average / MAX) << " \n";

	return 0;
}