#include <string>
#include <iostream>
#include "classes.h"
using namespace std;


int main()
{
	double id;
	double date;
	string name;

	cout << " please enter your id number: " << endl;
	cin >> id;
	cout << "please eneter your name: " << endl;
	cin >> name;
	cout << "please enter your hire date please" << endl;
	cin >> date;
	
	double time;

	cout << " please enter your hours: " << endl;
	cin >> time;
	
	productionworker myworker(id,name,date,time);
	
	cout << "your id number is: "<< myworker.getemployeenumber() << endl;
	cout << "your hire date is: " << myworker.gethiredate() << endl;
	cout << "your name is: "<< myworker.getemployeename() << endl;
	cout << "your shift is: " << myworker.getshift() << endl;
	cout << "your payrate is: " << myworker.getpayrate() << endl;
	return 0;
}