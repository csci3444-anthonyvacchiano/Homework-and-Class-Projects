#include "classes.h"

void productionworker::shifttime(double time)
{
	if (time < 9)
		payrate = 9;
	else
		payrate = 8;
	totpay();
}
void productionworker::totpay()
{
	double totalpay;

	totalpay = shift * payrate;
}