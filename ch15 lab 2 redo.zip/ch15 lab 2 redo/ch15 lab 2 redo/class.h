#pragma once
#ifndef CLASS_H
#define CLASS_H 
#include <iostream>
#include <string>
using namespace std;

class Employee
{
private:
	double employeenumber;
	double hiredate;
	string employeename;
public:
	Employee()
	{
		employeenumber = 0;
		hiredate = 0;
		employeename = " ";
	}
	Employee(double enumber, double hdate, string ename)
	{
		employeenumber = enumber;
		hiredate = hdate;
		employeename = ename;
	}
	double getemployeenumber() const
	{
		return employeenumber;
	}
	double gethiredate() const
	{
		return hiredate;
	}
	string getemployeename() const
	{
		return employeename;
	}
};
#endif