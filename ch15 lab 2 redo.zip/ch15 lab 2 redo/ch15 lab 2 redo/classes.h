#pragma once
#ifndef CLASSES_H
#define CLASSES_H
#include "class.h"

class productionworker : public Employee
{
protected:
	double shift;
	double payrate;
public:
	productionworker() : Employee()
	{
		shift = 0;
		payrate = 0.0;
	}
	productionworker(int s, double pr) : Employee()
	{
		shift = s;
		payrate = pr;
	}
	double getshift()
	{
		return shift;
	}
	double getpayrate() const
	{
		return payrate;
	}
	void shifttime(double);
	void totpay();
};
#endif