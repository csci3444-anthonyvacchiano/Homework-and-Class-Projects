#include "dayofyear.h"
#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

const string nummonth[] = { "janaury", "febuary", " march", " april", "may", "june ", "july", "august ", "september", "october", "november", "december" };
const int dayyear[] = { 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

void dayofyear::simmonth(int day)
{
	int month = 0;
	int finalday = 0;
	while (dayyear[month] < day)
	{
		month = (month + 1);
		finalday = day - dayyear[month - 1];
	}
	if (month < 1)
	{
		finalday = day;
	}
	
	//Display month and day
	cout << "the date is " << nummonth[month] << " " << finalday << endl;
}
// days at end of the month [31,59,90,120,151,181,212,243,273,304,334, 365];
// while days at the end of the month[month] = day)
//month = ( month +1)%12;