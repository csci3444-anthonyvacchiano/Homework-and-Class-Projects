#include <iostream>
#include "dayofyear.h"
using namespace std;

int main()
{
	int day;
	cout << "welcome to the day calculator please enter the day please!" << endl;
	cin >> day;
	if (day <= 0 || day > 365)
	{
		cout << "You must enter a valid number (1 thru 365)" << endl;
	}
	dayofyear answer(day);
	return 0;
}