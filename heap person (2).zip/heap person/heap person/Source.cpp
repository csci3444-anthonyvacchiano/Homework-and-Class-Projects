#include <iostream>
using namespace std;

class person {
public:
	string name;
	int age;
	int height;
	int weight;
	person()
	{
		name = " ";
		age = 0;
		height = 0;
		weight = 0;
	}
	person(string n, int a, int h, int w)
	{
		name = n;
		age = a;
		height = h;
		weight = w;
	}

	string getName()
	{
		return name;
	}
	int getAge()
	{
		return age;
	}
	int getHeight()
	{
		return height;
	}
	int getWeight()
	{
		return weight;
	}
};
class Heap{
	person A[15];
	int last = -1;
public:
	int getChildL(int n) {
		return 2 * n + 1;
	}
	int getChildR(int n) {
		return 2 * n + 2;
	}

	int getParent(int n) {
		if (n % 2 == 0) return n / 2 - 1;
		else			return n / 2;
	}

	void Insert(int x) {
		last++;
		A[last].age = x;
		Heapify(last);
	}
	void Heapify(int child) {
		int parent = getParent(child);
		//cout << "Parent of " << child << " is: " << parent<<endl;
		while (parent <= 0 && child > 0) {
			if (A[child].age < A[parent].age) {
				int temp = A[parent].age;
				A[parent].age = A[child].age;
				A[child].age = temp;
			}
			child = parent;
			parent = getParent(parent);
		}
	}

	int getHeapSize() {
		return last + 1;
	}


	void Delete(int x) {
		int index = -1;
		for (int i = 0; i <= last; i++) {
			if (A[i].age == x) { index = i; break; }
		}
		if (index == -1) {
			cout << "Element not found " << endl;
			return;
		}
		HeapifyDown(index);

	}

	void HeapifyDown(int parent) {
		A[parent] = A[last];
		last--;

		while (true) {
			int smallest = parent;

			int childL = getChildL(parent);
			int childR = getChildR(parent);

			if (childL <= last && A[childL].age < A[smallest].age) {
				smallest = childL;
			}
			if (childR <= last && A[childR].age < A[smallest].age) {
				smallest = childR;
			}

			if (smallest != parent) {
				int temp = A[parent].age;
				A[parent].age = A[smallest].age;
				A[smallest].age = temp;

				parent = smallest;
			}
			else {
				break;
			}
		}
	}



	void Print() {
		for (int i = 0; i <= last; i++) {
			cout << A[i].age << " ";
		}
		cout << endl;
	}



};


int main() {
	Heap heap;

	person one("bob", 20, 70, 187);
	person two("rob", 29, 60, 133);
	person three("eva", 10, 50, 144);
	person four("adam", 50, 70, 157);
	person five("jack", 90, 90, 197);

	heap.Insert(one.age); heap.Print();
	heap.Insert(two.age); heap.Print();
	heap.Insert(three.age); heap.Print();
	heap.Insert(four.age); heap.Print();
	heap.Insert(five.age); heap.Print();

	cout << "Deleting bob   \n"; 
	heap.Delete(one.age); heap.Print();


}