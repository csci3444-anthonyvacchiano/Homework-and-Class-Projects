#include <iostream>
#include "FeetInches.h"
#include "RoomDimension.h"
#include "RoomCarpet.h"
using namespace std;

int main()
{
	int l = 0;
	int w = 0;
	double cost = 0;
	int dimensions = 0;

	FeetInches length, width;

	cout << "please enter the inches and feet of the length " << endl;
	cin >> length;

	l = length;
	
	cout << "please enter the inches and feet of the width " << endl;
	cin >> width;

	w = width;

	cout << "please enter the cost per square feet " << endl;
	cin >> cost;
	
	RoomDimension area(l, w);
	dimensions = area.getArea();

	cout << "the area is " << dimensions << endl;

	RoomCarpet total(dimensions, cost);
	cout << " the final cost is " << total.getTotalCost << endl;


	return 0;
}