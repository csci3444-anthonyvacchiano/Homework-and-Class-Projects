#include <iostream>
using namespace std;
void insertionsort(int *A, int n);
void print(int cur, int *A);
int main()
{
	const int n = 4;
	int array[n] = {1,4,2,3};
	int i, j;
	insertionsort(array, n);
	return 0;
}
void insertionsort(int *A, int n)
{
	for (int i = 1; i < n; i++)
	{
		int cur = A[i];
		int j = i - 1;
		while ((j >= 0) && (A[j] > cur))
		{
			A[j + 1] = A[j];
			j--;
		}
		A[j + 1] = cur;
		print(n, A);
	}
}
void print(int n, int *A)
{
	cout << "sorting numbers: ";
	int q;
	for (q = 0; q<n; q++)
		for (q = 0; q<n; q++)
			cout << " " << A[q];
	cout << endl;
}