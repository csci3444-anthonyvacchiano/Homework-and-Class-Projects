#define TEMP_H
#include "temp.h"
#include <cstdlib>
#include <iostream>
using namespace std;

temperature::temperature(double T)
{
	temp = T;
    alcohol[0] = -173;
	alcohol[1] = 172;
    oxygen[0] = -362;
	oxygen[1] = -306 ;
    water[0] = 32;
	water[1] = 212;
}

bool temperature::isEthyFreezing()
{
	return (temp <= alcohol[0]);
}
bool temperature::isEthyBoiling()
{
	return (temp >= alcohol[1]);
}
bool temperature::isOxygenFreezing()
{
	return (temp <= oxygen[0]);
}
bool temperature::isOxygenBoiling()
{
	return (temp >= oxygen[1]);
}
bool temperature::isWaterFreezing()
{
	return (temp <= water[0]);
}
bool temperature::isWaterBoiling()
{
	return (temp >= water[1]);
}

void temperature::printitems()
{
	if (isEthyFreezing())
		cout << "Ethyl is freezing" << endl;
	if (isEthyBoiling())
		cout << "Ethyl is boiling" << endl;
	if (isOxygenFreezing())
		cout << "oxygen is freezing" << endl;
	if (isOxygenBoiling())
		cout << "oxygen is boiling" << endl;
	if (isWaterFreezing())
		cout << "water is freezing" << endl;
	if (isWaterBoiling())
		cout << "water is Boiling" << endl;
}