#include <iostream>
#include <cmath>
#include "temp.h"

using namespace std;

int main()
{
	double answer;

	cout << "enter temperature" << endl;
	cin >> answer;
	
	temperature degree(answer);
	degree.printitems();
}