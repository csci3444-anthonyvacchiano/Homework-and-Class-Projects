

class temperature
{
private:
	double temp;
	double alcohol[2];
	double oxygen[2];
	double water[2];

public:
	temperature(double);
	bool isEthyFreezing();
	bool isEthyBoiling();
	bool isOxygenFreezing();
	bool isOxygenBoiling();
	bool isWaterFreezing();
	bool isWaterBoiling();
	void printitems();

};


