#pragma once
#ifndef SHIP_H
#define SHIP_H
#include <string>
using namespace std;

class ship
{
protected:
	double data;
	string shipname;
	string shipyear;
public:
	ship()
	{
		data = 0.0;
		shipname = "";
		shipyear = "";
	}
	ship(double d, string name, string year)
	{
		data = d;
		shipname = name;
		shipyear = year;
	}
	string getname() const
	{
		return shipname;
	}
	string getyear() const
	{
		return shipyear;
	}
	void setdata(double d)
	{
		data = d;
	}
	double getdata() const
	{
		return data;
	}
	virtual void print() const;
};
#endif