#include <iostream>
#include "class.h"
using namespace std;

void displayship(const ship *);

int main()
{
	const int SHIPRAY = 3;

	ship *test[SHIPRAY] =
	{
		new ship(99, "ss discovery", "2005"),
		new cargoship(200),
		new cruiseship(10)
	};

	for (int count = 0; count < SHIPRAY; count++)
	{
		displayship(test[count]);
		cout << endl;
	}
	return 0;
}
void displayship(const ship *activity)
{
	cout << " the maxpass is :"<< activity->getdata() << endl;
	cout << " the tonnage is :" << endl;
	activity->print();
}