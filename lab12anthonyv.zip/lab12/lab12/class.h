#pragma once
#ifndef CLASS_H
#define CLASS_H
#include "ship.h"
class cruiseship : public ship
{
protected:
	int maxpas;
public:
	cruiseship() : ship()
	{
		maxpas = 0;
	}
	cruiseship(double mp) : ship()
	{
		maxpas = mp;
	}
	void setcruiseship(double mp)
	{
		maxpas = mp;
	}
	double getmaxpas() const
	{
		return maxpas;
	}
	virtual void print() const override;

};

class cargoship : public ship
{
protected:
	int tonnage;
public:
	cargoship() : ship()
	{
		tonnage = 0;
	}
	cargoship(double t) : ship()
	{
		tonnage = t;
	}
	void settonnage(double t)
	{
		tonnage = t;
	}
	double gettonnage() const
	{
		return tonnage;
	}
	virtual void print() const override;
};
#endif