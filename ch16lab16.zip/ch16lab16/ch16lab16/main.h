#pragma once
#ifndef MAIN_H
#define MAIN_H
#include <string>
using namespace std;

class employee
{
private:
	string name;
	double employeenum;
	double hiredate;
public:
	class invalidemployeenum
	{
	private:
		double value;
	public:
		invalidemployeenum()
		{
			value = 0;
		}
		invalidemployeenum(double ivnum)
		{
			value = ivnum;
		}
		double getvalue() const
		{
			return value;
		}
	};
	employee()
	{
		employeenum = 0;
		hiredate = 0;
		name = " ";
	}
	double getemployeenumber() const
	{
		return employeenum;
	}
	double gethiredate() const
	{
		return hiredate;
	}
	string getemployeename() const
	{
		return name;
	}
	void setnum(double);
};
#endif