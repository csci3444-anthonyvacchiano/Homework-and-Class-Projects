#include "employee.h"

void productionworker::shifttime(int shift)
{
	if (shift < 9)
	{
		payrate = 9;
	}
	else
	{
		payrate = 8;
	}
	totpay();
}
void productionworker::totpay()
{
	double totalpay;

	totalpay = shift * payrate;
}

void productionworker::setpayrate(double py)
{
	if (py > 0)
		throw invalidpayrate(py);
	else
		payrate = py;
}
void productionworker::setshift(double s)
{
	if (s > 0 || s < 10)
		throw invalidshift(s);
	else
		shift = s;
}
