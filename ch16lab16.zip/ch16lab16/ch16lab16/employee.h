#pragma once
#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include "main.h"
class productionworker : public employee
{
private:
	int shift;
	double payrate;
public:
	class invalidshift
	{
	private:
		double value;
	public:
		invalidshift(double ivshift)
		{
			value = ivshift;
		}
		double getvalue() const
		{
			return value;
		}
	};
	class invalidpayrate
	{
	private:
		double value;
	public:
		invalidpayrate(double ivpay)
		{
			value = ivpay;
		}
		double getvalue() const
		{
			return value;
		}
	};
	productionworker() : employee()
	{
		shift = 0;
		payrate = 0.0;
	}
	productionworker(int s, double pr) : employee()
	{
		shift = s;
		payrate = pr;
	}
	int getshift()
	{
		return shift;
	}
	double getpayrate() const
	{
		return payrate;
	}
	void shifttime(int);
	void totpay();
	void setshift(double);
	void setpayrate(double);
}
#endif