#include <string>
#include <iostream>
#include "employee.h"
using namespace std;


int main()
{
	double id;
	double date;
	string name;
	employee e;

	cout << " please enter your id number: " << endl;
	cin >> id;
	cout << "please eneter your name: " << endl;
	cin >> name;
	cout << "please enter your hire date please" << endl;
	cin >> date;

	try
	{
	e.setnum(id);
	}
	catch (employee::invalidemployeenum)
	{
		cout << "error, must input positive number" << endl;
	}

	int time;
	double payrate;
	productionworker PW;

	cout << " please enter your hours: " << endl;
	cin >> time;
	cout << "please enter payrate: " << endl;
	cin >> payrate;

	try
	{
	PW.setpayrate(payrate);
	PW.setshift(time);
	}
	catch (productionworker::invalidpayrate)
	{
		cout << "error, must input positive number" << endl;
	}
	catch (productionworker::invalidshift)
	{
		cout << "error, must input positive number and one thats under 10." << endl;
	}

	return 0;
}
void employee::setnum(double i)
{
	if (i >= 99999)
		i = id;
	else
		throw invalidemployeenum();
}