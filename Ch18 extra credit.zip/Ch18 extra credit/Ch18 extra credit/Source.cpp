#include <iostream>       // std::cin, std::cout
#include <stack>          // std::queue
#include <string>
using namespace std;

int main()
{
	std::stack<char> mystack;
	char myint;
	char begint[] = { '{' , '[', '(' };
	char endint[] = { '}', ']', ')' };
	string statement[] = { "braces", " brackets", " parentheses" };
	char quit = '0';
	int trueint = begint[0] || begint[1] || begint[2];
	int i = 3;

	std::cout << "Please enter some integers (enter 0 to end):\n";

	do {
		std::cin >> myint;

		if (myint = trueint)
		{

			trueint = begint[i];
			mystack.push(myint);
		}
		else if (myint = endint[i])
		{
			mystack.top();
			mystack.pop();
		cout << "this statement contains" << statement[i] << endl;
		}

		//mystack.pop();
		//mystack.push(trueint);
	} while (myint != '0');

	std::cout << "myqueue contains: ";
	while (!mystack.empty())
	{
		std::cout << ' ' << mystack.top();
		mystack.pop();
	}
	std::cout << '\n';

	return 0;
}