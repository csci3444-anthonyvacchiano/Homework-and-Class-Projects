#include <iostream>
#include <cmath>
#include "fcall.h"

using namespace std;

int main()
{
	bankaccount bank1;

	double rectdollar;
	double rectcent;
	cout << " please enter the ammount of dollars in the account " << endl;
	cin >> rectdollar;
	cout << " please enter the ammount of cents in the account " << endl;
	cin >> rectcent;


	bank1.setdollar(rectdollar);
	bank1.setcent(rectcent);

	bank1.getdeposit();
	bank1.getwithdraw();

}