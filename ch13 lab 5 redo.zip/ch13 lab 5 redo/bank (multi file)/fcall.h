#ifndef functioncall_h
#define functioncall_h

class bankaccount
{
private:
	double dollar;  /// monthly payment
	double cent; //// interest rate
public:
	void setdollar(double);
	void setcent(double);
	double getdeposit();
	double getwithdraw();
};
#endif