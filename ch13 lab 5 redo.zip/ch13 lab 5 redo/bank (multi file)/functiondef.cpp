#include "fcall.h"
#include <math.h>
#include <iostream>
using namespace std;

void bankaccount::setdollar(double d)
{
	dollar = d;
}
void bankaccount::setcent(double c)
{
	cent = c;
}
double bankaccount::getdeposit()
{
	char  again;
	int ddollar = 0;
	int dcent = 0;
	do
	{
		cout << "please enter the amount of dollars you want to deposit :$" << endl;
		cin >> ddollar;
		cout << " now please enter the cents: c" << endl;
		cin >> dcent;

		dollar += ddollar;
		cent += dcent;
		if (cent > 99)
		{
			cent -= 100;
			dollar += 1;
		}

		cout << "your dollar amount is " << dollar << " and " << cent << " cents." << endl;
		cout << " want to do it again?" << endl;
		cin >> again;
	} while (again == 'y');
	return 0;
}
double bankaccount::getwithdraw()
{
	char  again;
	int wdollar = 0;
	int wcent = 0;
	do
	{
		cout << "please enter the amount of dollars you want to withdraw." << endl;
		cin >> wdollar;
		cout << " now please enter the cents." << endl;
		cin >> wcent;
		dollar -= wdollar;
		cent -= wcent;
		if (cent < 0)
		{
			cent += 99;
			dollar -= 1;
		}
			cout << "your dollar amount is " << dollar << " and " << cent << " cents." << endl;

		cout << " want to do it again?" << endl;
		cin >> again;
	} while (again == 'y');
	return 0;
}