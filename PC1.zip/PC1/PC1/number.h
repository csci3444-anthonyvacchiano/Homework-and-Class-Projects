

class number
{
private:
	int numb;
public:
	number(int value=0) { numb = value; }
	void print();
};


