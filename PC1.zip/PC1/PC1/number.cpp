#include <string>
#include <iomanip>
#include <iostream>
#include "number.h"

using namespace std;



const string lessthan20[] = { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
"eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty" };

const string hundrednumber[] = { "hundred" };

const string thousand[] = { " thousand",};

const string tens[] = { "twenty", "thirty" ,  "fourty", "fitfy" , "sixty" , "seventy" , "eighty","ninety" };


void number::print()
{
	string result;
	int test;
	double hundred;
	double tens;
	double other;
	test = numb / 1000;
	if (test > 0)
	{
		result += lessthan20[test - 1];
		result += " " + thousand[0] + " ";
		hundred = numb % 1000;
		if (hundred > 0)
		{
			test = hundred / 100;
			result += lessthan20[test - 1];
			result += " " + hundrednumber[0] + " ";
			tens = numb % 100;
			
		//	other = test % 10;
			if (tens > 0)
			{
				test = hundred / 10;
				result += lessthan20[test - 1];
				cout << result;
			}
		}
	}		
	//cout << result << endl;

}


