#include <iostream>
#include <cstring>
#include "number.h"
#include <fstream>

using namespace std;

int main()
{
	
	double moneyamount;
	string writtenamount; /// run 120 of visual studios
	string numberStrings;
	cout << "please enter the dollar amount" << endl;
	cin >> moneyamount;
	number num(moneyamount);
	num.print();

	cout << " your dollar amount is ";

	return 0;

}