#include <iostream>       // std::cin, std::cout
#include <stack>          // std::queue
#include <string>

int main()
{
	std::stack<char> mystack;
	char myint;
	char trueint;
	char quit = '0';

	std::cout << "Please enter some integers (enter 0 to end):\n";

	do {
		std::cin >> myint;
	
		if (myint = '(')
		{
			mystack.push(myint);
		}
		else if (trueint = ')')
			{ 
				mystack.top();
				mystack.pop();
			}		
		
		//mystack.pop();
		//mystack.push(trueint);
	} 
	while (myint != '0');

	std::cout << "myqueue contains: ";
	while (!mystack.empty())
	{
		std::cout << ' ' << mystack.top();
		mystack.pop();
	}
	std::cout << '\n';

	return 0;
}