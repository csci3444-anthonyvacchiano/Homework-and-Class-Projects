#include <iostream>
using namespace std;

int A(int, int);

int main()
{
	cout << "welcome to the Ackermann's function calculator! \n" << endl;
	int m;
	cout << "enter m value: ";
	cin >> m;
	
	int n;
	cout << "enter n value: ";
	cin >> n;

	int newm;
	newm = A(m, n);

	cout << " we got " << newm << "! \n";

	return 0;

}

int A(int m, int n)
{
	if (m == 0)
	{
		cout << "m is " << m << "\n";
		cout << "n is" << n << "\n";
		cout << "m = 0, return n + 1 \n \n";
		return n + 1;
	}

	if (n == 0)
	{
		cout << "m is " << m << "\n";
		cout << "n is " << n << "\n";
		cout << "n = 0,A(m - 1, 1) \n \n";
		return A(m - 1, 1);
	}
	else
	{
		cout << "m is " << m << "\n";
		cout << "n is " << n << "\n";
		cout << "A(m - 1, A(m, n - 1)) \n \n";
		return A(m - 1, A(m, n - 1));
	}
}