#include <iostream>

using namespace std;

template <class T>
T total(T number, T ftotal)
{
	ftotal += number;
	return ftotal;
}
int main()
{
	int num;
	int tot = 0;

	do
	{
		cout << "please enter in a positive number: \n";
		cin >> num;
		cout << "the total is : " << total(num, tot) << " \n";
		tot = total(num, tot);
	}
	while (num > 0);


	return 0;
}