#include <iostream>
#include "NumberList.h"
using namespace std;

int main()
{
	NumberList list;
	NumberList copylist;

	list.appendNode(2.5);	
	list.appendNode(7.9);
	list.appendNode(12.6);
	
	list.insertNode(10.5);

	list.displayList();
	list.deleteNode(2.5);
	list.deleteNode(7.9);
	list.deleteNode(12.6);

	copylist = list;
	copylist.displayList();

	list.displayList();
	return 0;
}