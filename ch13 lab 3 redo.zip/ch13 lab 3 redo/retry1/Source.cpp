#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

const int MAX_LENGTH = 50;
class Floatlist
{
public:
	void getList(ifstream&);
	void printlist() const;

	Floatlist();
	~Floatlist();

private:
	int length;
	float values[MAX_LENGTH];
};

int main()
{
	ifstream tempData;
	const int MAX_LENGTH = 5;
	//list of floatlist
	Floatlist list;  //create object

	cout << fixed << showpoint;
	cout << setprecision(2);

	tempData.open("temperatures.txt");

	//getlist function
	list.getList(tempData);
	list.printlist();
	//printlist function

	return 0;
}
Floatlist::Floatlist()
{
	int length = 0;///set private data length to zero
}
void Floatlist::getList(ifstream& inputFile)
{
	//ifstream inputFile;
	inputFile.open("temperatures.txt");
	int i = 0;
	while (inputFile)
	{
		inputFile >> values[i];
		i++;
	}

}
// Fill in the entire code for the getList function
// The getList function reads the data values from a data file
// into the values array of the class FloatList
void Floatlist::printlist() const
{
	for (int i = 0; i < 5; i++)
		cout << values[i] << endl;
}
// Fill in the entire code for the printList function
// The printList function prints to the screen the data in
// the values array of the class FloatList
Floatlist::~Floatlist()
{
	delete [] values;
}
// Fill in the code for the implementation of the destructor