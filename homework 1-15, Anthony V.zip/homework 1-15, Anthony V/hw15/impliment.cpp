#include "payment.h"
#include <math.h>
using namespace std;

void payment::setloan(double l)
{
	loan = l;
}
void payment::setrate(double r)
{
	rate = r;
}
void payment::setyear(double y)
{
	year = y;
}
double payment::monrate()
{
	double monthly = rate / 12;
	return monthly;
}
double payment::getterm()
{
	double term = pow((1 + monrate()),12);
	return term;
}
double payment::getpayment()
{
	double term = getterm();
	double payment = (loan * monrate() * term) / (term - 1);
	return payment;
}
double payment::bank()
{
	double total = getpayment() * year * 12;
	return total;
}