#ifndef payment_h
#define payment_h

class payment
{
private:
	double loan;  /// monthly payment
	double rate; //// interest rate
	double year; //// years of the loan
public:
	void setloan(double);
	void setrate(double);
	void setyear(double);
	double monrate(); /// term/12
	double getterm();
	double getpayment();
	double bank();
};
#endif