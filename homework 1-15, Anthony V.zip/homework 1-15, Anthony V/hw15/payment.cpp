#include <iostream>
#include <cmath>
#include "payment.h"

using namespace std;

int main()
{
	payment money;

	double rectloan;
	double rectrate;
	double rectyear;

	cout << " welcome to the mortage calculator. " << endl;
	cout << " please enter how much your loan is " << endl;
	cin >> rectloan;
	cout << " please enter how much your rate is " << endl;
	cin >> rectrate;
	cout << " please enter how many years are in the mortage " << endl;
	cin >> rectyear;

	money.setloan(rectloan);
	money.setrate(rectrate);
	money.setyear(rectyear);

	cout << "here are the important details. " << endl;
	cout << " the payment is $" << money.getpayment() << endl;
	cout << "your total payments to the bank is $" << money.bank() << endl;
}