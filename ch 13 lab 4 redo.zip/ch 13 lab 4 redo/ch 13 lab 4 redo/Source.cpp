#include <iostream>
#include <fstream>
using namespace std;


const int NUMOFPROD = 10;

class Inventory
{
public:
	void getId(int item);

	void getAmount(int num);

	void display();

private:
	int itemNumber;
	int NumOfItem;
};

int main()
{
	int pos;
	int id;
	int total;
	ifstream infile;
	infile.open("Inventory.dat");

	///define array of objects of inventory class called products, same size as NUMOFPROD;
	for (int product = 0; product <= NUMOFPROD; product++)
	{
		itemNumber[product];
		id[pos] = products[pos].getId(id);
		total[pos] = products[pos].getAmount(total);
	}
	inventory.display();

	/// open the file, then read the file, elememnts, create a loop that goes to 0 to the array.


	// Fill in the code that will read inventory numbers and number of items
	// from a file into the array of objects. There should be calls to both
	// getId and getAmount member functions somewhere in this code.
	// Example: products[pos].getId(id); will be somewhere in this code
	// Fill in the code to print out the values (itemNumber and numOfItem) for
	// each object in the array products.
	// This should be done by calling the member function display within a loop

	return 0;
}
Inventory::Inventory()
{
	int pos = 0;
	int id = 0;
	int total = 0;
}
void Inventory::getId()
{
	inputFile.open{ "Inventory.dat" };
	int i = 0;
	while (inputFile)
	{
		inputFile >> id[i];
		i++;
	}
}
void Inventory::getAmount()
{
	inputFile.open{ "Inventory.dat" };
	int i = 0;
	while (inputFile)
	{
		inputFile >> total[i];
		i++;
	}
}
void Inventory::display()
{
	inputFile.open{ "Inventory.dat" };
	int i = 0;
	while (inputFile)
	{
		inputFile >> total[i];
		inputFile >> id[i];
		cout << id[i] << endl;
		cout << total[i] << endl;
		i++;
	}
}